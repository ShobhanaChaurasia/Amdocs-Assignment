package com.uxpsystems.assignment.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.uxpsystems.assignment.dao.UserDaoImpl;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.uxpsystems.assignment" })
public class WebConfig {
	  @Bean
	    public RestTemplate template(){
	        return new RestTemplate();
	    }
	}
