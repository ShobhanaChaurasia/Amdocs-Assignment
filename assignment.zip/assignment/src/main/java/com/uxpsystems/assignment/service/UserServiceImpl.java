package com.uxpsystems.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uxpsystems.assignment.dao.UserDao;
import com.uxpsystems.assignment.modal.User;

@Service("userService")
@Transactional
public class UserServiceImpl implements UserService {

   @Autowired
   private UserDao userDao;

 
   public long saveUser(User user) {
	   System.out.println("inside save service :");
      return userDao.saveUser(user);
   }

   
   public User getUser(long id) {
      return userDao.getUser(id);
   }

   
   public List<User> listUser() {
      return userDao.listUser();
   }


   public void updateUser(long id, User user) {
      userDao.updateUser(id, user);
   }

 
   public void deleteUser(long id) {
      userDao.deleteUser(id);
   }

}
