package com.uxpsystems.assignment.dao;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Repository;

import com.uxpsystems.assignment.modal.User;

@Repository("userDao")
public class UserDaoImpl extends AbstractDao implements UserDao {

  
@Autowired
   private SessionFactory sessionFactory;

 
 	public long saveUser(User user) {
	  System.out.println("inside dao");
	  sessionFactory.getCurrentSession().save(user);
	  return user.getId();
 	}

	public User getUser(long id) {
	  return sessionFactory.getCurrentSession().get(User.class, id);
	 
	}


	public List<User> listUser() {
		 Session session = sessionFactory.getCurrentSession();
		    CriteriaBuilder cb = session.getCriteriaBuilder();
		    CriteriaQuery<User> cq = cb.createQuery(User.class);
		    Root<User> root = cq.from(User.class);
		    cq.select(root);
		    Query<User> query = session.createQuery(cq);
		    return query.getResultList();
	}

	
	public void updateUser(long id, User user) {
      Session session = sessionFactory.getCurrentSession();
      User user2 = session.byId(User.class).load(id);
      user2.setUserName(user.getUserName());
      user2.setPassword(user.getPassword());
      session.flush();

	}

	
	public void deleteUser(long id) {
		 Session session = sessionFactory.getCurrentSession();
	      User user = session.byId(User.class).load(id);
	      session.delete(user);
		
	}

}