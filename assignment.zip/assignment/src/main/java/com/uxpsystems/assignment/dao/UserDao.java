package com.uxpsystems.assignment.dao;


import java.util.List;
import com.uxpsystems.assignment.modal.User;

public interface UserDao {

   public long saveUser(User user);
   public User getUser(long id);
   public List<User> listUser();
   public void updateUser(long id, User user);
   public void deleteUser(long id);

}