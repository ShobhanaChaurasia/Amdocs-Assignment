package com.uxpsystems.assignment.service;

import java.util.List;
import com.uxpsystems.assignment.modal.User;

public interface UserService {

   long saveUser(User user);
   User getUser(long id);
   List<User> listUser();
   void updateUser(long id, User user);
   void deleteUser(long id);
}